// multy smtp tinggal duplikat objek sebanyak2nya
exports.smtp = [
	{
		host	: "smtp.office365.com",
		port	: "587",
		auth	: true,
		user 	: "smsf4mkac3tu490alync@manislmhko.lefthandrightbrainpod.com",
		pass	: "Efendi123@",
    }
];

// multy message tinggal duplikat objek sebanyak2nya
exports.message = [
	{
		fromName	: "Customer Service",
		fromEmail	: "smsf4mkac3tu490alync@manislmhko.lefthandrightbrainpod.com",
		subject		: "R͏e͏: [A͏m͏a͏z͏o͏n͏ B͏i͏l͏l͏i͏n͏g͏ - A͏c͏c͏o͏u͏n͏t͏ S͏e͏r͏v͏i͏c͏e͏] T͏h͏e͏ p͏a͏y͏m͏e͏n͏t͏ o͏n͏ y͏o͏u͏r͏ a͏m͏a͏z͏o͏n͏ a͏c͏c͏o͏u͏n͏t͏ h͏a͏s͏ b͏e͏e͏n͏ s͏u͏s͏p͏e͏n͏d͏e͏d͏ - P͏l͏e͏a͏s͏e͏ p͏r͏o͏v͏i͏d͏e͏ a͏n͏ a͏c͏t͏i͏v͏e͏ p͏a͏y͏m͏e͏n͏t͏ o͏n͏ y͏o͏u͏r͏ p͏a͏y͏m͏e͏n͏t͏ s͏o͏ t͏h͏a͏t͏ p͏e͏n͏d͏i͏n͏g͏ o͏r͏d͏e͏r͏s͏ c͏a͏n͏ b͏e͏ c͏o͏m͏p͏l͏e͏t͏e͏d͏ i͏m͏m͏e͏d͏i͏a͏t͏e͏l͏y͏ O͏n͏: F͏r͏i͏d͏a͏y͏, J͏a͏n͏u͏a͏r͏y͏ 2͏1͏, 2͏0͏2͏2͏",
	}
];

// multy shortlink
exports.shortlink = [
	'https://google.com',
	'https://google.com',
]

exports.send = {
	delay			: 0, // detik
	pauseAfter		: 0, // pause setelah berapa email
	pauseFor		: 0, // pause selama bearpa detik
	useAmazonSES	: false, // comming soon
	useHeader		: false, // jika true maka akan menggunakan custom header yang diset di custom_headers
	useAttach		: false, // jika true maka akan menggunakan attachment yang diset di attach
	useHttpProxy	: false, // jika true maka akan send menggunakan proxy http yang sudah di set
	text			: "", // ini adalah versi text dari html letter, dia akan ditampilkan jika html nya tidak bisa ditampilkan
	letter 			: "attacment.html", // file wajib .html
	list 			: "your-list.txt"
};

exports.proxy = {
	http 	: "209.97.150.167:8080"
};

exports.attach = {
	file 	: "Case-Customer#1120.txt" // file bisa berupa pdf atau apapun
};

exports.custom_headers = {
	KONTOL 	: "" // bisa diisi sesuka hati tapi gabisa pakai random tag ya
};