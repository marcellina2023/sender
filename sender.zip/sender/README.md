
# YourSender
tool for sending bulk emails with a lot of customization. developed using node.js based on nodemailer

### Features

-   support smtp without auth
-   random tag for text customization
-   send using http proxy
-   delay every emails
-   support pdf attachment
-   support custom headers
-   multy random smtp
-   multy random subject, fromname, fromemail
-   pause for a few seconds after how many emails

this is the complete source code from https://sourceforge.net/projects/yoursender/
