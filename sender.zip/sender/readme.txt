changelog :

version 1.0.2

- added multy shortlink

version 1.0.1

- fix multy random smtp issue
- added pause for a few seconds after how many emails
- added logs for failed deliveries


version 1.0.0

- added multy random smtp
- added multy random subject, fromName, fromEmail
- added new tag
- new clean interface


regards, yoursender (one of the best free email senders)